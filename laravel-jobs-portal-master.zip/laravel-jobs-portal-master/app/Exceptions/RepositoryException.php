<?php 

namespace App\Exceptions;

class RepositoryException extends \Exception
{
	
}