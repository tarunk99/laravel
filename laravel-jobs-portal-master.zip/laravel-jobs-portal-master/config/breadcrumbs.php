<?php

return [

	// resources/views/themes/bootstrap/breadcrumbs.blade.php
	'view' => 'themes/bootstrap/breadcrumbs'

];
